package com.example.final_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
